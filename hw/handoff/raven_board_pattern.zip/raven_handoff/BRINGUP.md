# RAVEN Ultra96-V2 bring-up (PATTERN package)

RAVEN board prototype build
built: 2026-11-24 20:39:56 -0500
vivado: 2025.2
git: 3cba04a1d25104af216fc91c0060edb6b53efaed on refs/heads/nahjay_control_prototype (uncommitted changes: unknown)
part: xczu3eg-sbva484-1-i  board: avnet.com:ultra96v2:part0:1.2
out0_source: PATTERN
raven window: 0xA4000000, 16K (JTAG-to-AXI address space)
pl_clk0: 50.000000 MHz (clk_pl_0 period 20.000 ns)
timing: WNS 7.667 ns, WHS 0.012 ns
bring-up: see the header of board_bringup_xsdb.tcl, then run_fixture.tcl -smoke

## Quick steps (PATTERN package)

Full details, including the fixture step and troubleshooting, are in
`hw/README.md` ("Bring up the board") in the repository.

1. Ultra96-V2 with the JTAG pod on J3, and SW3 set to JTAG boot (or no SD card). Power on.
2. Unzip to a folder, for example `raven_handoff/`.
3. Program and initialize. This must print `RAVEN_BRINGUP_COMPLETE`:

   ```sh
   xsdb raven_handoff/board_bringup_xsdb.tcl raven_handoff
   ```

4. Smoke test. This must print `RAVEN_SMOKE_PASS`:

   ```sh
   vivado -mode batch -source raven_handoff/run_fixture.tcl -tclargs -smoke
   ```

   If the NPU was left busy or halted, add `-soft_reset`.

Report back the console output of both steps, especially any failure in the three
"AXI error as expected" checks or in the xsdb target selection. Those are the parts
that could not be tested without the board.

